<template>
  <div />
</template>

<script>
export default {
  props: ['resource', 'resourceName', 'resourceId'],
}
</script>
